<?php
/**
 * Plugin Name: AURA Photo Awards
 * Description: Photography contest platform with jury evaluation system
 * Version: 1.2.0
 * Author: Your Name
 * Text Domain: aura-photo-awards
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AURA_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('AURA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AURA_VERSION', '1.2.0');
define('AURA_BADGES_PATH', AURA_PLUGIN_PATH . 'assets/badges/');
define('AURA_BADGES_URL', AURA_PLUGIN_URL . 'assets/badges/');

// Add shortcodes
add_action('init', 'aura_register_shortcodes');

function aura_register_shortcodes() {
    add_shortcode('aura_submit_photo', array(new AURA_Submission(), 'render_submission_form'));
}

// Include the activator class first
require_once AURA_PLUGIN_PATH . 'includes/class-aura-activator.php';

// Plugin activation hook
register_activation_hook(__FILE__, 'aura_activate_plugin');

function aura_activate_plugin() {
    // Create custom tables
    AURA_Activator::create_tables();
    
    // Create upload directory
    $upload_dir = wp_upload_dir();
    $aura_dir = $upload_dir['basedir'] . '/aura-photos';
    if (!file_exists($aura_dir)) {
        wp_mkdir_p($aura_dir);
    }
    
    // Set default options
    if (!get_option('aura_credits_price')) {
        add_option('aura_credits_price', array(
            '1' => 10,
            '3' => 20,
            '5' => 30,
            '10' => 50
        ));
    }
}

// Plugin initialization
add_action('plugins_loaded', 'aura_init_plugin');

function aura_init_plugin() {
    // Load text domain
    load_plugin_textdomain('aura-photo-awards', false, dirname(plugin_basename(__FILE__)) . '/languages');
    
    // Initialize components
    require_once AURA_PLUGIN_PATH . 'includes/class-aura-loader.php';
    require_once AURA_PLUGIN_PATH . 'includes/class-aura-judging.php';
}

// Add Admin Menu
add_action('admin_menu', 'aura_register_admin_menu');

function aura_register_admin_menu() {
    add_menu_page(
        __('AURA Photo Awards', 'aura-photo-awards'),
        __('AURA Photo Awards', 'aura-photo-awards'),
        'manage_options',
        'aura-photo-awards',
        null,
        'dashicons-camera',
        25
    );

    add_submenu_page(
        'aura-photo-awards',
        __('Manage User Credits', 'aura-photo-awards'),
        __('Manage Credits', 'aura-photo-awards'),
        'manage_options',
        'aura-manage-credits',
        array('AURA_Contest', 'render_manage_credits_page')
    );
    
    add_submenu_page(
        'aura-photo-awards',
        __('Create Contest', 'aura-photo-awards'),
        __('Create Contest', 'aura-photo-awards'),
        'manage_options',
        'aura-create-contest',
        array('AURA_Contest', 'render_create_contest_page')
    );

    add_submenu_page(
        'aura-photo-awards',
        __('Submissions', 'aura-photo-awards'),
        __('Submissions', 'aura-photo-awards'),
        'manage_options',
        'aura-submissions',
        array('AURA_Submissions', 'render_submissions_page')
    );

    add_submenu_page(
        'aura-photo-awards',
        __('Judging', 'aura-photo-awards'),
        __('Judging', 'aura-photo-awards'),
        'manage_options',
        'aura-judging',
        array('AURA_Judging', 'render_judging_page')
    );
}

