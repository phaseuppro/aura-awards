<?php
if (!defined('ABSPATH')) exit;

$user_credits = get_user_meta(get_current_user_id(), 'aura_credits', true);
?>

<div class="aura-submission-form">
    <?php if (!is_user_logged_in()): ?>
        <p><?php echo wp_kses_post(__('Please <a href="' . wp_login_url(get_permalink()) . '">login</a> to submit photos.', 'aura-photo-awards')); ?></p>
    <?php elseif ($user_credits < 1): ?>
        <div class="aura-credits-info">
            <?php echo wp_kses_post(__('You need credits to submit photos. <a href="' . get_permalink(get_option('aura_shop_page')) . '">Purchase credits</a>', 'aura-photo-awards')); ?>
        </div>
    <?php else: ?>
        <div class="aura-credits-info">
            <?php printf(esc_html__('Available Credits: %d', 'aura-photo-awards'), intval($user_credits)); ?>
        </div>
        
        <div id="aura-submission-messages"></div>
        
        <form id="aura-submission-form" enctype="multipart/form-data">
            <?php wp_nonce_field('aura_photo_submission', 'nonce'); ?>
            
            <div class="aura-form-group">
                <label for="photo-upload"><?php esc_html_e('Select Photo', 'aura-photo-awards'); ?></label>
                <input type="file" id="photo-upload" name="photo" accept=".jpg,.jpeg" required>
                <div class="file-requirements">
                    <small><?php esc_html_e('Image Requirements:', 'aura-photo-awards'); ?></small>
                    <ul>
                        <li><?php esc_html_e('Format: JPG/JPEG only', 'aura-photo-awards'); ?></li>
                        <li><?php esc_html_e('Size: 1MB to 6MB', 'aura-photo-awards'); ?></li>
                        <li><?php esc_html_e('Dimensions: 2048px to 4000px on longest side', 'aura-photo-awards'); ?></li>
                    </ul>
                </div>
            </div>

            <!-- Preview Image Container -->
            <div class="aura-form-group aura-submission-preview">
                <label><?php esc_html_e('Photo Preview:', 'aura-photo-awards'); ?></label>
                <img id="preview-image" src="" alt="<?php esc_attr_e('Preview', 'aura-photo-awards'); ?>" style="max-height: 100px; display: none; margin-top: 10px;">
            </div>
            
            <div class="aura-form-group">
                <label for="category"><?php esc_html_e('Category', 'aura-photo-awards'); ?></label>
                <select id="category" name="category" required>
                    <option value=""><?php esc_html_e('Select Category', 'aura-photo-awards'); ?></option>
                    <option value="maternity"><?php esc_html_e('Maternity', 'aura-photo-awards'); ?></option>
                    <option value="newborn"><?php esc_html_e('Newborn', 'aura-photo-awards'); ?></option>
                    <option value="children"><?php esc_html_e('Children', 'aura-photo-awards'); ?></option>
                    <option value="family"><?php esc_html_e('Family', 'aura-photo-awards'); ?></option>
                    <option value="ai-infused"><?php esc_html_e('AI-Infused', 'aura-photo-awards'); ?></option>
                </select>
            </div>
            
            <div class="aura-form-group">
                <label for="title"><?php esc_html_e('Title (Optional)', 'aura-photo-awards'); ?></label>
                <input type="text" id="title" name="title" maxlength="100">
            </div>
            
            <div class="aura-form-group">
                <label for="description"><?php esc_html_e('Description (Optional)', 'aura-photo-awards'); ?></label>
                <textarea id="description" name="description" rows="4" maxlength="500"></textarea>
            </div>

            <div class="aura-form-group">
                <div class="upload-progress" style="display: none;">
                    <div class="progress-bar"></div>
                </div>
            </div>
            
            <button type="submit" class="aura-submit-btn"><?php esc_html_e('Submit Photo', 'aura-photo-awards'); ?></button>
        </form>
    <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
    const fileInput = $('#photo-upload');
    const previewImage = $('#preview-image');

    fileInput.on('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                previewImage.attr('src', event.target.result).show();
            };
            reader.readAsDataURL(file);
        } else {
            previewImage.hide();
        }
    });
});
</script>
