<?php
class AURA_Contest {
    public static function render_create_contest_page() {
        // Check user permissions
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have permission to access this page.', 'aura-photo-awards'));
        }

        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('aura_create_contest')) {
            $title = sanitize_text_field($_POST['contest_title']);
            $description = sanitize_textarea_field($_POST['contest_description']);
            $start_date = sanitize_text_field($_POST['start_date']);
            $end_date = sanitize_text_field($_POST['end_date']);

            // Validate dates
            if (strtotime($start_date) > strtotime($end_date)) {
                echo '<div class="error"><p>' . __('Start date cannot be after end date.', 'aura-photo-awards') . '</p></div>';
            } else {
                $post_id = wp_insert_post(array(
                    'post_title'   => $title,
                    'post_content' => $description,
                    'post_status'  => 'publish',
                    'post_type'    => 'contest',
                    'meta_input'   => array(
                        'start_date' => $start_date,
                        'end_date'   => $end_date,
                    ),
                ));

                if (is_wp_error($post_id)) {
                    echo '<div class="error"><p>' . __('Error creating contest.', 'aura-photo-awards') . '</p></div>';
                } else {
                    echo '<div class="updated"><p>' . __('Contest created successfully.', 'aura-photo-awards') . '</p></div>';
                }
            }
        }

        // Render the form
        ?>
        <div class="wrap">
            <h1><?php _e('Create Contest', 'aura-photo-awards'); ?></h1>
            <form method="post">
                <?php wp_nonce_field('aura_create_contest'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="contest_title"><?php _e('Contest Title', 'aura-photo-awards'); ?></label></th>
                        <td><input type="text" id="contest_title" name="contest_title" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="contest_description"><?php _e('Description', 'aura-photo-awards'); ?></label></th>
                        <td><textarea id="contest_description" name="contest_description" class="large-text" rows="5" required></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="start_date"><?php _e('Start Date', 'aura-photo-awards'); ?></label></th>
                        <td><input type="date" id="start_date" name="start_date" required></td>
                    </tr>
                    <tr>
                        <th><label for="end_date"><?php _e('End Date', 'aura-photo-awards'); ?></label></th>
                        <td><input type="date" id="end_date" name="end_date" required></td>
                    </tr>
                </table>
                <p class="submit">
                    <button type="submit" class="button button-primary"><?php _e('Create Contest', 'aura-photo-awards'); ?></button>
                </p>
            </form>
        </div>
        <?php
    }

    public static function render_manage_credits_page() {
        // Check user permissions
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have permission to access this page.', 'aura-photo-awards'));
        }

        // Handle form submission for credit adjustments
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('aura_manage_credits')) {
            $user_id = intval($_POST['user_id']);
            $credits = intval($_POST['credits']);
            $action = sanitize_text_field($_POST['action_type']);

            if ($action === 'add') {
                $current_credits = get_user_meta($user_id, 'aura_credits', true);
                update_user_meta($user_id, 'aura_credits', $current_credits + $credits);
                echo '<div class="updated"><p>' . __('Credits added successfully.', 'aura-photo-awards') . '</p></div>';
            } elseif ($action === 'subtract') {
                $current_credits = get_user_meta($user_id, 'aura_credits', true);
                $new_credits = max(0, $current_credits - $credits); // Prevent negative credits
                update_user_meta($user_id, 'aura_credits', $new_credits);
                echo '<div class="updated"><p>' . __('Credits subtracted successfully.', 'aura-photo-awards') . '</p></div>';
            }
        }

        // Render user list and form
        $users = get_users();
        ?>
        <div class="wrap">
            <h1><?php _e('Manage User Credits', 'aura-photo-awards'); ?></h1>
            <form method="post">
                <?php wp_nonce_field('aura_manage_credits'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="user_id"><?php _e('Select User', 'aura-photo-awards'); ?></label></th>
                        <td>
                            <select id="user_id" name="user_id" required>
                                <option value=""><?php _e('Select a user', 'aura-photo-awards'); ?></option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo esc_attr($user->ID); ?>">
                                        <?php echo esc_html($user->display_name . ' (' . $user->user_email . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="credits"><?php _e('Credits', 'aura-photo-awards'); ?></label></th>
                        <td><input type="number" id="credits" name="credits" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="action_type"><?php _e('Action', 'aura-photo-awards'); ?></label></th>
                        <td>
                            <select id="action_type" name="action_type" required>
                                <option value="add"><?php _e('Add Credits', 'aura-photo-awards'); ?></option>
                                <option value="subtract"><?php _e('Subtract Credits', 'aura-photo-awards'); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <button type="submit" class="button button-primary"><?php _e('Submit', 'aura-photo-awards'); ?></button>
                </p>
            </form>
        </div>
        <?php
    }
}
