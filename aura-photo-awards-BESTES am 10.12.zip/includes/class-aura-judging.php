<?php
class AURA_Judging {
    public function __construct() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('wp_ajax_aura_load_thumbnails', array($this, 'load_thumbnails'));
        add_action('wp_ajax_aura_save_judgment', array($this, 'save_judgment'));
        add_action('wp_ajax_aura_reject_submission', array($this, 'reject_submission'));
    }

    public function enqueue_assets($hook) {
        if ($hook !== 'aura-photo-awards_page_aura-judging') {
            return;
        }

        wp_enqueue_style('aura-judging', AURA_PLUGIN_URL . 'assets/css/judging.css', array(), AURA_VERSION);
        wp_enqueue_script('aura-judging', AURA_PLUGIN_URL . 'assets/js/judging.js', array('jquery'), AURA_VERSION, true);

        wp_localize_script('aura-judging', 'auraJudging', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('aura_judging_nonce'),
        ));
    }

    public static function render_judging_page() {
        ?>
        <div class="aura-judging-dashboard">
            <div class="aura-judging-thumbnails">
                <h3><?php _e('Pending Submissions', 'aura-photo-awards'); ?></h3>
                <div id="thumbnail-list"></div>
            </div>
            <div class="aura-judging-main">
                <h3><?php _e('Selected Photo', 'aura-photo-awards'); ?></h3>
                <div id="selected-photo"></div>
            </div>
            <div class="aura-judging-controls">
                <h3><?php _e('Judging Panel', 'aura-photo-awards'); ?></h3>
                <!-- Reject Submission Button -->
                <button id="reject-submission" class="reject-button"><?php _e('Reject Submission', 'aura-photo-awards'); ?></button>
                <div id="rating-panel">
                    <?php
                    $criteria = array('light', 'pose', 'idea', 'emotion', 'colors');
                    foreach ($criteria as $criterion) {
                        echo '<div style="display: flex; align-items: center; justify-content: space-between;">';
                        echo '<label>' . esc_html(ucfirst($criterion)) . ':</label>';
                        echo '<div class="rating-stars" data-criterion="' . esc_attr($criterion) . '">';
                        for ($i = 1; $i <= 5; $i++) {
                            echo '<span class="rating-star" data-value="' . $i . '">☆</span>';
                        }
                        echo '</div></div>';
                    }
                    ?>
                </div>
                <!-- Display Jury Points and Badge -->
                <div id="jury-summary" class="jury-points-badge">
                    <p id="jury-points"><?php _e('Jury Points: 0', 'aura-photo-awards'); ?></p>
                    <p id="badge-result"><?php _e('Assigned Badge: Participant', 'aura-photo-awards'); ?></p>
                </div>
                <div id="badge-panel">
                    <h4><?php _e('Badge Position', 'aura-photo-awards'); ?></h4>
                    <button data-position="top-left"><?php _e('Top Left', 'aura-photo-awards'); ?></button>
                    <button data-position="top-right"><?php _e('Top Right', 'aura-photo-awards'); ?></button>
                    <button data-position="bottom-left"><?php _e('Bottom Left', 'aura-photo-awards'); ?></button>
                    <button data-position="bottom-right"><?php _e('Bottom Right', 'aura-photo-awards'); ?></button>
                </div>
                <button id="judge-save"><?php _e('Judge & Save', 'aura-photo-awards'); ?></button>
            </div>
        </div>
        <?php
    }

    public function load_thumbnails() {
        check_ajax_referer('aura_judging_nonce', 'nonce');

        $args = array(
            'post_type'      => 'photo_submission',
            'posts_per_page' => -1,
            'post_status'    => 'pending',
        );
        $query = new WP_Query($args);
        $thumbnails = array();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $thumbnails[] = array(
                    'id'    => get_the_ID(),
                    'title' => get_the_title(),
                    'src'   => get_the_post_thumbnail_url(get_the_ID(), 'thumbnail') ?: '',
                );
            }
        }
        wp_send_json_success($thumbnails);
    }

    public function save_judgment() {
        check_ajax_referer('aura_judging_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have permission to perform this action.', 'aura-photo-awards'));
        }

        $post_id = intval($_POST['post_id']);
        if (!$post_id || get_post_type($post_id) !== 'photo_submission') {
            wp_send_json_error(__('Invalid photo submission.', 'aura-photo-awards'));
        }

        $ratings = isset($_POST['ratings']) ? $_POST['ratings'] : array();
        $total_stars = 0;

        foreach ($ratings as $criterion => $value) {
            if (!in_array($criterion, array('light', 'pose', 'idea', 'emotion', 'colors')) || !is_numeric($value) || $value < 1 || $value > 5) {
                wp_send_json_error(__('Invalid rating value.', 'aura-photo-awards'));
            }
            $total_stars += intval($value);
            update_post_meta($post_id, "_aura_rating_{$criterion}", intval($value));
        }

        $jury_points = $total_stars * 4;
        update_post_meta($post_id, '_aura_jury_points', $jury_points);

        $badge = 'Participant';
        if ($jury_points >= 90) $badge = 'Platinum';
        elseif ($jury_points >= 70) $badge = 'Gold';
        elseif ($jury_points >= 50) $badge = 'Silver';
        elseif ($jury_points >= 30) $badge = 'Bronze';

        update_post_meta($post_id, '_aura_badge', $badge);

        $badge_position = sanitize_text_field($_POST['position']);
        update_post_meta($post_id, '_aura_badge_position', $badge_position);

        wp_update_post(array(
            'ID'          => $post_id,
            'post_status' => 'reviewed',
        ));

        wp_send_json_success(array(
            'message'       => __('Judgment saved successfully.', 'aura-photo-awards'),
            'jury_points'   => $jury_points,
            'badge'         => $badge,
        ));
    }

    public function reject_submission() {
        check_ajax_referer('aura_judging_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have permission to perform this action.', 'aura-photo-awards'));
        }

        $post_id = intval($_POST['post_id']);
        if (!$post_id || get_post_type($post_id) !== 'photo_submission') {
            wp_send_json_error(__('Invalid photo submission.', 'aura-photo-awards'));
        }

        $user_id = get_post_field('post_author', $post_id);
        $credits = (int) get_user_meta($user_id, 'aura_credits', true);
        update_user_meta($user_id, 'aura_credits', $credits + 1);

        wp_delete_post($post_id, true);

        wp_send_json_success(__('Submission rejected successfully.', 'aura-photo-awards'));
    }
}
