<?php
class AURA_Submission_Admin {
    public function __construct() {
        add_action('add_meta_boxes', array($this, 'add_rating_metabox'));
        add_action('save_post', array($this, 'save_submission_ratings'));
        add_filter('manage_photo_submission_posts_columns', array($this, 'add_rating_column'));
        add_action('manage_photo_submission_posts_custom_column', array($this, 'populate_rating_column'), 10, 2);
    }

    // Add the metabox for ratings
    public function add_rating_metabox() {
        add_meta_box(
            'aura_submission_rating',
            __('Submission Ratings', 'aura-photo-awards'),
            array($this, 'render_rating_metabox'),
            'photo_submission',
            'side',
            'high'
        );
    }

    // Render the rating metabox
    public function render_rating_metabox($post) {
        $criteria = array('light', 'pose', 'idea', 'emotion', 'colors');
        $ratings = array();

        foreach ($criteria as $criterion) {
            $ratings[$criterion] = get_post_meta($post->ID, "_aura_rating_{$criterion}", true);
        }

        // Display the rating fields
        echo '<div class="aura-rating-fields">';
        foreach ($criteria as $criterion) {
            $value = isset($ratings[$criterion]) ? intval($ratings[$criterion]) : 0;
            echo '<label for="aura-rating-' . esc_attr($criterion) . '">' . esc_html(ucfirst($criterion)) . ':</label>';
            echo '<select name="aura_rating_' . esc_attr($criterion) . '" id="aura-rating-' . esc_attr($criterion) . '">';
            echo '<option value="0">' . __('Select', 'aura-photo-awards') . '</option>';
            for ($i = 1; $i <= 5; $i++) {
                echo '<option value="' . esc_attr($i) . '" ' . selected($value, $i, false) . '>' . esc_html($i) . '</option>';
            }
            echo '</select><br>';
        }
        echo '</div>';

        // Nonce field for security
        wp_nonce_field('aura_save_ratings', 'aura_ratings_nonce');
    }

    // Save the ratings when the post is saved
    public function save_submission_ratings($post_id) {
        if (!isset($_POST['aura_ratings_nonce']) || !wp_verify_nonce($_POST['aura_ratings_nonce'], 'aura_save_ratings')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if ('photo_submission' !== get_post_type($post_id)) {
            return;
        }

        $criteria = array('light', 'pose', 'idea', 'emotion', 'colors');
        $total_rating = 0;

        foreach ($criteria as $criterion) {
            if (isset($_POST["aura_rating_{$criterion}"])) {
                $rating = intval($_POST["aura_rating_{$criterion}"]);
                if ($rating < 1 || $rating > 5) {
                    continue;
                }
                update_post_meta($post_id, "_aura_rating_{$criterion}", $rating);
                $total_rating += $rating;
            }
        }

        // Save the total rating as a separate meta field
        update_post_meta($post_id, '_aura_total_rating', $total_rating);
    }

    // Add a column for the total rating in the post list table
    public function add_rating_column($columns) {
        $columns['aura_total_rating'] = __('Total Rating', 'aura-photo-awards');
        return $columns;
    }

    // Populate the rating column in the post list table
    public function populate_rating_column($column, $post_id) {
        if ('aura_total_rating' === $column) {
            $total = get_post_meta($post_id, '_aura_total_rating', true);
            echo esc_html($total ? $total : __('Not Rated', 'aura-photo-awards'));
        }
    }
}

// Initialize the admin class
new AURA_Submission_Admin();
