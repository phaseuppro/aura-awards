jQuery(document).ready(function ($) {
    function calculateJuryPoints() {
        let totalStars = 0;

        $('.rating-stars').each(function () {
            const stars = $(this).find('.active').length;
            totalStars += stars;
        });

        const juryPoints = totalStars * 4; // Each star equals 4 jury points
        let badge = 'Participant';

        if (juryPoints >= 90) badge = 'Platinum';
        else if (juryPoints >= 70) badge = 'Gold';
        else if (juryPoints >= 50) badge = 'Silver';
        else if (juryPoints >= 30) badge = 'Bronze';

        $('#jury-points').text(`Jury Points: ${juryPoints}`);
        $('#badge-result').text(`Assigned Badge: ${badge}`);
    }

    // Load thumbnails dynamically
    function loadThumbnails() {
        $.ajax({
            url: auraJudging.ajaxurl,
            method: 'POST',
            data: {
                action: 'aura_load_thumbnails',
                nonce: auraJudging.nonce,
            },
            success: function (response) {
                if (response.success) {
                    const thumbnailList = $('#thumbnail-list');
                    thumbnailList.empty();
                    response.data.forEach(function (thumb) {
                        thumbnailList.append(
                            `<img src="${thumb.src}" class="thumbnail" data-id="${thumb.id}" title="${thumb.title}" />`
                        );
                    });
                }
            },
            error: function () {
                alert('Failed to load thumbnails.');
            },
        });
    }

    // Handle thumbnail selection
    $('#thumbnail-list').on('click', '.thumbnail', function () {
        const photoId = $(this).data('id');
        const thumbnailSrc = $(this).attr('src');

        $('.thumbnail').removeClass('active');
        $(this).addClass('active');

        $('#selected-photo').html(`<img src="${thumbnailSrc}" data-id="${photoId}" />`);
        $('#photo-details').text(`Photo ID: ${photoId}`);
    });

    // Handle star rating click
    $('.rating-stars').on('click', 'span', function () {
        const $this = $(this);
        $this
            .siblings()
            .removeClass('active')
            .end()
            .prevAll()
            .addBack()
            .addClass('active');

        calculateJuryPoints(); // Update Jury Points and Badge on every click
    });

    // Handle badge position button click
    $('#badge-panel button').on('click', function () {
        $('#badge-panel button').removeClass('active');
        $(this).addClass('active');
    });

    // Reject submission
    $('#reject-submission').on('click', function () {
        const photoId = $('#selected-photo img').data('id');
        if (!photoId) {
            alert('Please select a photo to reject.');
            return;
        }

        if (!confirm('Are you sure you want to reject this submission? This action is irreversible.')) {
            return;
        }

        $.ajax({
            url: auraJudging.ajaxurl,
            method: 'POST',
            data: {
                action: 'aura_reject_submission',
                nonce: auraJudging.nonce,
                post_id: photoId,
            },
            success: function (response) {
                if (response.success) {
                    alert('Submission rejected successfully.');
                    loadThumbnails(); // Reload thumbnails to update the list
                    $('#selected-photo').empty();
                    $('#photo-details').empty();
                    $('.rating-stars span').removeClass('active');
                    $('#badge-panel button').removeClass('active');
                    $('#jury-points').text('Jury Points: 0');
                    $('#badge-result').text('Assigned Badge: Participant');
                } else {
                    alert(response.data || 'Failed to reject submission.');
                }
            },
            error: function () {
                alert('An error occurred while rejecting the submission.');
            },
        });
    });

    // Save judgment via AJAX
    $('#judge-save').on('click', function () {
        const photoId = $('#selected-photo img').data('id');
        if (!photoId) {
            alert('Please select a photo to judge.');
            return;
        }

        const ratings = {};
        $('.rating-stars').each(function () {
            const criterion = $(this).data('criterion');
            const value = $(this).find('.active').length;
            ratings[criterion] = value || 0;
        });

        const badgePosition = $('#badge-panel button.active').data('position');

        $.ajax({
            url: auraJudging.ajaxurl,
            method: 'POST',
            data: {
                action: 'aura_save_judgment',
                nonce: auraJudging.nonce,
                post_id: photoId,
                ratings: ratings,
                position: badgePosition,
            },
            success: function (response) {
                if (response.success) {
                    alert('Judgment saved successfully.');
                    loadThumbnails(); // Reload thumbnails to update the list
                    $('#selected-photo').empty();
                    $('#photo-details').empty();
                    $('.rating-stars span').removeClass('active');
                    $('#badge-panel button').removeClass('active');
                    $('#jury-points').text('Jury Points: 0');
                    $('#badge-result').text('Assigned Badge: Participant');
                } else {
                    alert(response.data || 'Failed to save judgment.');
                }
            },
            error: function () {
                alert('An error occurred while saving the judgment.');
            },
        });
    });

    // Load initial thumbnails
    loadThumbnails();
});
